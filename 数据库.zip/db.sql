/*
SQLyog Ultimate v12.3.1 (64 bit)
MySQL - 5.7.31-log : Database - db_equipment
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_equipment` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_equipment`;

/*Table structure for table `t_baofei` */

DROP TABLE IF EXISTS `t_baofei`;

CREATE TABLE `t_baofei` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `equipmentname` varchar(20) DEFAULT NULL,
  `yuanyin` varchar(20) DEFAULT NULL,
  `zhuangtai` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_baofei` */

insert  into `t_baofei`(`id`,`equipmentname`,`yuanyin`,`zhuangtai`) values 
(1,'发电机','功率小，换大的',1),
(2,'4','5',0),
(3,'9','测试',1),
(4,'电脑','换代',0),
(5,'101','huan',1);

/*Table structure for table `t_baoxiu` */

DROP TABLE IF EXISTS `t_baoxiu`;

CREATE TABLE `t_baoxiu` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `equipmentname` varchar(20) DEFAULT NULL,
  `weixiushijian` varchar(20) DEFAULT NULL,
  `yuanyin` varchar(50) DEFAULT NULL,
  `jieguo` varchar(50) DEFAULT NULL,
  `weixiuren` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_baoxiu` */

insert  into `t_baoxiu`(`id`,`equipmentname`,`weixiushijian`,`yuanyin`,`jieguo`,`weixiuren`) values 
(1,'键盘','2021/4/10','w不灵','失败','老张'),
(2,'叉车','2','2','2','2'),
(4,NULL,'2','2','2','2');

/*Table structure for table `t_caigou` */

DROP TABLE IF EXISTS `t_caigou`;

CREATE TABLE `t_caigou` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `equipmentname` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `shuliang` int(20) DEFAULT NULL,
  `price` int(10) DEFAULT NULL,
  `fuzeren` varchar(20) DEFAULT NULL,
  `beizhu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_caigou` */

insert  into `t_caigou`(`id`,`equipmentname`,`time`,`shuliang`,`price`,`fuzeren`,`beizhu`) values 
(1,'发电机','2021-04-12 00:00:00',4,5,'6','99'),
(2,'96','2021-04-12 13:38:45',4,5,'6','6'),
(3,'发电机','2021-04-12 17:29:06',2,2,'2','2'),
(4,'发电机','2021-04-12 12:46:02',1,1,'1','1'),
(5,'2','5',5,4,'5','5'),
(6,'5','4',7,7,'7','7'),
(7,'6','6',6,6,'6','6'),
(8,'9','9',9,9,'9','9'),
(9,'22','22',22,22,'22','22'),
(10,'6','6',5,64,'4','5'),
(11,'54','75',545,54,'54','54');

/*Table structure for table `t_chuku` */

DROP TABLE IF EXISTS `t_chuku`;

CREATE TABLE `t_chuku` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `equipmentname` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `shuliang` int(20) DEFAULT NULL,
  `fuzeren` varchar(20) DEFAULT NULL,
  `beizhu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_chuku` */

insert  into `t_chuku`(`id`,`equipmentname`,`time`,`shuliang`,`fuzeren`,`beizhu`) values 
(1,'101','1',1,'1','3'),
(2,'11','22',33,'44','55'),
(3,'9','9',9,'9','9'),
(4,'99','88',99,'88','99'),
(5,'36','5',4,'5','2'),
(6,'发电机','2021-04-13 15:38:04',15,'12','12'),
(7,'发电机','2021-04-13 00:00:00',2,'2','2');

/*Table structure for table `t_equipment` */

DROP TABLE IF EXISTS `t_equipment`;

CREATE TABLE `t_equipment` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(500) DEFAULT NULL,
  `changshang` varchar(50) DEFAULT NULL,
  `daxiao` varchar(50) DEFAULT NULL,
  `guige` varchar(50) DEFAULT NULL,
  `kucun` int(5) DEFAULT NULL,
  `del` int(2) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_equipment` */

insert  into `t_equipment`(`id`,`name`,`changshang`,`daxiao`,`guige`,`kucun`,`del`) values 
(1,'发电机','山东胜动动力机械有限公司','300*120*60','GKH1600',6,0),
(2,'叉车','中力叉车','271*122*270','KG1000',71,0),
(4,'电脑','联想','18寸','拯救者9',1,1),
(5,'9','9','9','9',9,1),
(6,'101','101','11','13',1,1);

/*Table structure for table `t_root` */

DROP TABLE IF EXISTS `t_root`;

CREATE TABLE `t_root` (
  `loginname` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_root` */

insert  into `t_root`(`loginname`,`password`,`username`) values 
('root','root','张主管'),
('admin','admin','王经理');

/*Table structure for table `t_ruku` */

DROP TABLE IF EXISTS `t_ruku`;

CREATE TABLE `t_ruku` (
  `id` int(3) NOT NULL AUTO_INCREMENT,
  `equipmentname` varchar(20) DEFAULT NULL,
  `time` varchar(20) DEFAULT NULL,
  `shuliang` varchar(20) DEFAULT NULL,
  `fuzeren` varchar(20) DEFAULT NULL,
  `beizhu` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_ruku` */

insert  into `t_ruku`(`id`,`equipmentname`,`time`,`shuliang`,`fuzeren`,`beizhu`) values 
(1,'发电机','2021-04-12 13:26:07','2','2','2'),
(2,'叉车','2021-04-22 00:00:00','6','7','9'),
(3,'3','2021-04-12 00:00:14','4','5','5'),
(5,'99','88','77','99','88'),
(7,'101','2021-03-17 00:00:00','3','1','2'),
(8,'发电机','2021-04-13 15:21:53','12','5','5'),
(9,'101','2021-04-13 00:00:00','100','1','1'),
(10,'发电机','2021-04-13 15:33:50','1','3','3'),
(11,'叉车','2021-04-13 00:00:00','70','70','70');

/*Table structure for table `t_user` */

DROP TABLE IF EXISTS `t_user`;

CREATE TABLE `t_user` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `age` int(10) DEFAULT NULL,
  `tel` varchar(30) DEFAULT NULL,
  `loginname` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `del` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

/*Data for the table `t_user` */

insert  into `t_user`(`id`,`username`,`sex`,`age`,`tel`,`loginname`,`password`,`del`) values 
(1,'张三','男',25,'13256223521','zs','zs',0),
(2,'李四','男',26,'13656635634','ls','ls',0),
(3,'王五','女',24,'14568565414','ww','ww',0),
(4,'郑六','男',19,'12345665432','ll','ll',1),
(5,'陈七','女',28,'45641563695','cq','cq',0),
(6,'朱八','男',32,'14589632560','zb','zb',0);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
